package com.IsilSoftSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IsilSoftSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(IsilSoftSpringApplication.class, args);
	}

}
